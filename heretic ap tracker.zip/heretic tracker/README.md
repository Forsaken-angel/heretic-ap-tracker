# Heretic Archipelago Tracker

Heretic Archipelago tracker pack for [PopTracker](https://github.com/black-sliver/PopTracker/) with Autotracking.

You can download AP Doom/Heretic over at: https://github.com/Daivuk/apdoom/releases

PopTracker v0.25.0 or higher is recommended.

Ethereal Crossbow, Gauntlets of the Necromancer, and Bag of Holding still dont autotrack yet and I've yet to figure out why.

# Full credit of this pack should go to Ozone, their tracker for DOOM 1993 was of the most help! And Seto10987 for assisting with locating the IDs for the items/locations and double checking my screw ups!